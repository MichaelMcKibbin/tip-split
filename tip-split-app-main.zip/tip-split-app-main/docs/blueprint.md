# **App Name**: TipSplit

## Core Features:

- Bill Input: Allow users to input the total bill amount.
- Tip Calculation: Calculate the tip amount based on a percentage (e.g., 15%, 20%, custom).
- Split Calculation: Calculate the amount each person owes, including tip.
- Number of People: Adjust the number of people splitting the bill.
- Custom Tip: Ability to enter a custom tip percentage.

## Style Guidelines:

- Primary color: Soft purple (#BB86FC) for a modern feel.
- Background color: Light pink (#F8BBD0), desaturated hue of the primary color
- Accent color: Pink (#F48FB1) for interactive elements and highlights, an analogous hue to the primary color with adjusted saturation and brightness to create good contrast.
- Body and headline font: 'Poppins', a geometric sans-serif for a modern feel
- Use simple, clean icons for ease of understanding.
- Clean and intuitive layout for easy navigation.
- Subtle animations to enhance user experience when splitting amounts.