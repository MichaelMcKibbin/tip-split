import TipCalculator from "@/components/calculator/TipCalculator";
import { Sparkles } from "lucide-react";

export default function Home() {
  return (
    <main className="min-h-screen bg-background relative overflow-hidden flex flex-col items-center justify-start py-8 px-4">
      {/* Decorative Circles */}
      <div className="absolute top-[-5%] left-[-10%] w-[50%] h-[30%] bg-primary/20 rounded-full blur-[80px] pointer-events-none" />
      <div className="absolute bottom-[-5%] right-[-10%] w-[50%] h-[30%] bg-accent/20 rounded-full blur-[80px] pointer-events-none" />
      
      <div className="z-10 w-full max-w-md text-center mb-8 animate-in fade-in zoom-in duration-1000">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-4">
          <Sparkles className="w-4 h-4 text-primary" />
          <span className="text-[10px] font-bold text-primary uppercase tracking-widest">Mobile Billing</span>
        </div>
        <h1 className="text-4xl md:text-5xl font-black text-primary mb-2 tracking-tighter">
          Tip<span className="text-accent">Split</span>
        </h1>
        <p className="text-muted-foreground text-sm font-medium max-w-xs mx-auto leading-relaxed">
          Fast calculations for your next group meal.
        </p>
      </div>

      <div className="w-full max-w-md z-10">
        <TipCalculator />
      </div>

      <footer className="mt-auto pt-12 pb-6 text-muted-foreground/60 text-xs font-medium z-10 flex flex-col items-center gap-4">
        <p>© {new Date().getFullYear()} TipSplit. Better group dinners.</p>
        <div className="flex gap-6">
          <a href="#" className="hover:text-primary transition-colors">Privacy</a>
          <a href="#" className="hover:text-primary transition-colors">Terms</a>
        </div>
      </footer>
    </main>
  );
}
