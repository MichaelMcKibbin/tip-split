"use client"

import React, { useState, useEffect } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Users, DollarSign, Percent, RotateCcw, Plus, Minus } from 'lucide-react';
import { cn } from "@/lib/utils";

const tipPercentages = [10, 15, 20, 25];

export default function TipCalculator() {
  const [bill, setBill] = useState<string>("");
  const [tipPercent, setTipPercent] = useState<number>(15);
  const [people, setPeople] = useState<number>(1);
  const [customTip, setCustomTip] = useState<string>("");
  const [isCustom, setIsCustom] = useState<boolean>(false);

  const [results, setResults] = useState({
    tipAmount: 0,
    totalAmount: 0,
    perPerson: 0,
    tipPerPerson: 0
  });

  useEffect(() => {
    const billNum = parseFloat(bill) || 0;
    const actualTipPercent = isCustom ? (parseFloat(customTip) || 0) : tipPercent;
    
    const tipAmount = (billNum * actualTipPercent) / 100;
    const totalAmount = billNum + tipAmount;
    const perPerson = totalAmount / people;
    const tipPerPerson = tipAmount / people;

    setResults({
      tipAmount,
      totalAmount,
      perPerson,
      tipPerPerson
    });
  }, [bill, tipPercent, people, customTip, isCustom]);

  const handleReset = () => {
    setBill("");
    setTipPercent(15);
    setPeople(1);
    setCustomTip("");
    setIsCustom(false);
  };

  const handleCustomToggle = () => {
    setIsCustom(true);
    setTipPercent(0);
  };

  const incrementPeople = () => setPeople(prev => Math.min(prev + 1, 100));
  const decrementPeople = () => setPeople(prev => Math.max(prev - 1, 1));

  return (
    <div className="w-full animate-in fade-in slide-in-from-bottom-4 duration-700">
      <Card className="overflow-hidden border-none shadow-2xl bg-white/90 backdrop-blur-lg rounded-[2.5rem]">
        <CardContent className="p-0">
          <div className="flex flex-col">
            {/* Input Side */}
            <div className="p-8 space-y-6">
              <div className="space-y-3">
                <Label htmlFor="bill" className="text-sm font-bold text-primary flex items-center gap-2 uppercase tracking-wider">
                  <DollarSign className="w-4 h-4" />
                  Total Bill
                </Label>
                <div className="relative group">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground group-focus-within:text-primary transition-colors text-xl font-semibold">$</span>
                  <Input
                    id="bill"
                    type="number"
                    placeholder="0.00"
                    value={bill}
                    onChange={(e) => setBill(e.target.value)}
                    className="pl-10 h-16 text-2xl font-bold rounded-2xl border-none bg-muted/30 focus:bg-white transition-all shadow-inner"
                  />
                </div>
              </div>

              <div className="space-y-3">
                <Label className="text-sm font-bold text-primary flex items-center gap-2 uppercase tracking-wider">
                  <Percent className="w-4 h-4" />
                  Tip Percentage
                </Label>
                <div className="grid grid-cols-2 gap-3">
                  {tipPercentages.map((percent) => (
                    <Button
                      key={percent}
                      variant={!isCustom && tipPercent === percent ? "default" : "secondary"}
                      onClick={() => {
                        setTipPercent(percent);
                        setIsCustom(false);
                      }}
                      className={cn(
                        "h-14 text-lg font-bold rounded-2xl transition-all border-none",
                        !isCustom && tipPercent === percent ? "bg-primary text-primary-foreground scale-[1.02] shadow-lg shadow-primary/20" : "bg-muted/40 text-muted-foreground hover:bg-primary/10"
                      )}
                    >
                      {percent}%
                    </Button>
                  ))}
                  <div className="col-span-2 relative">
                    <Input
                      type="number"
                      placeholder="Custom %"
                      value={customTip}
                      onFocus={handleCustomToggle}
                      onChange={(e) => setCustomTip(e.target.value)}
                      className={cn(
                        "h-14 text-center text-lg font-bold rounded-2xl border-none transition-all shadow-inner",
                        isCustom ? "bg-primary/10 text-primary ring-2 ring-primary" : "bg-muted/40"
                      )}
                    />
                    {isCustom && <span className="absolute right-4 top-1/2 -translate-y-1/2 text-primary font-bold">%</span>}
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <Label className="text-sm font-bold text-primary flex items-center gap-2 uppercase tracking-wider">
                    <Users className="w-4 h-4" />
                    Split With
                  </Label>
                  <span className="text-xl font-black text-accent">{people} {people === 1 ? 'person' : 'people'}</span>
                </div>
                <div className="flex items-center gap-4 bg-muted/30 p-4 rounded-2xl">
                   <Button 
                    size="icon" 
                    variant="ghost" 
                    onClick={decrementPeople}
                    className="shrink-0 rounded-xl h-10 w-10 bg-white shadow-sm text-accent hover:bg-accent hover:text-white"
                  >
                    <Minus className="w-4 h-4" />
                  </Button>
                  <Slider
                    value={[people]}
                    min={1}
                    max={20}
                    step={1}
                    onValueChange={(val) => setPeople(val[0])}
                    className="flex-grow"
                  />
                  <Button 
                    size="icon" 
                    variant="ghost" 
                    onClick={incrementPeople}
                    className="shrink-0 rounded-xl h-10 w-10 bg-white shadow-sm text-accent hover:bg-accent hover:text-white"
                  >
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Display Side */}
            <div className="p-8 bg-primary/5 border-t border-primary/10 rounded-b-[2.5rem] space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-1">
                  <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-primary/60">Tip / Person</h3>
                  <p className="text-2xl font-black text-primary">
                    ${results.tipPerPerson.toFixed(2)}
                  </p>
                </div>
                <div className="space-y-1 text-right">
                  <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-accent/60">Total / Person</h3>
                  <p className="text-3xl font-black text-accent drop-shadow-sm">
                    ${results.perPerson.toFixed(2)}
                  </p>
                </div>
              </div>

              <div className="pt-6 border-t border-primary/10 space-y-3">
                <div className="flex justify-between text-xs font-bold uppercase tracking-widest text-muted-foreground/60">
                  <span>Grand Total</span>
                  <span className="text-primary font-black">${results.totalAmount.toFixed(2)}</span>
                </div>
              </div>

              <Button
                onClick={handleReset}
                variant="ghost"
                className="w-full h-14 text-xs font-black uppercase tracking-[0.3em] text-primary/50 hover:text-primary hover:bg-primary/10 rounded-2xl transition-all group"
              >
                <RotateCcw className="w-4 h-4 mr-2 group-hover:rotate-180 transition-transform duration-500" />
                Reset All
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
